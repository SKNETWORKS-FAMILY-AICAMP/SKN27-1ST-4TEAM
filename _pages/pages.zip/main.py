
from common.sidemenu import display_sidebar  # 공통 모듈 임포트
#공통 사이드바 호출
display_sidebar()